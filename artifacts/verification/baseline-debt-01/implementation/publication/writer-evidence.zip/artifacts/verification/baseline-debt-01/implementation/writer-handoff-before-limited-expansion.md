==================================================
BASELINE-DEBT-01 WRITER HANDOFF — IMPLEMENTATION
==================================================

TASK_ID: BASELINE-DEBT-01
START_SHA: 86d5939044c1d7ec2a991820f39287481ee9120f
BRANCH: feature/baseline-debt-01-deterministic-lifecycle-cleanup
ARCHITECTURE_DECISION: HUMAN_ACCEPTED / IMPLEMENTATION_AUTHORIZED
RESULT: SCOPE_EXPANSION_REQUIRED

ROOT_CAUSE_A: occurred_at / random UUID sorting cannot represent durable append order.
ROOT_CAUSE_B: operation and cleanup shared a deadline policy; short tests raced setup;
external caller cancellation escaped cleanup and durable state persistence.

MIGRATION: 0003_run_event_sequence (down_revision=0002)
LEGACY_POLICY: per-Run physical rowid insertion-order reconstruction, legacy flag TRUE;
not causal-time proof. Identity/state/timestamp/reason preserved; downgrade loses
ordering metadata but retains events; re-upgrade treats retained rows as legacy.
SEQUENCE_CONTRACT: persistence-only 1-based immutable per-Run durable append order;
atomic UPDATE RETURNING allocation, unique composite guard; ordinary updates exclude counter.
CANCELLATION_CONTRACT: protected bounded cleanup; verified CANCELLED else ORPHANED;
original CancelledError re-raised after service commit; persistence failure rolls back.

CHANGED_FILES:
- docs/10_DECISION_LOG.md
- docs/12_HANDOFF_CURRENT.md
- docs/15_DOCUMENT_INDEX.md
- docs/tasks/BASELINE-DEBT-01.md
- docs/35_ADR_014_DURABLE_EVENT_ORDERING_AND_CANCELLATION_CLEANUP.md
- services/core/src/polynexus_core/persistence/models.py
- services/core/src/polynexus_core/persistence/repository.py
- services/core/src/polynexus_core/runtime/supervisor.py
- services/core/src/polynexus_core/execution_service.py
- services/core/alembic/versions/0003_run_event_sequence.py
- services/core/tests/test_baseline_debt_01.py
- services/core/tests/test_baseline_debt_01_migration.py
- services/core/tests/test_wp09_query_api.py
- services/core/tests/test_wp12_council.py
- services/core/tests/test_wp14b_runtime_binding.py
- services/core/tests/test_wp24_resource_guards.py

MIGRATION_TESTS: 7 passed, combined focused command exit 0 (focused-final.xml/log).
FOCUSED_TESTS: 40 passed, including 24 durable cancellation cases across 3 service
entry paths and 2 persistence-failure rollback cases; combined total 47, exit 0.
DEBT_MATRIX: original 26 exact nodeids all passed within full-1.xml; standalone
matrix-1 exited 1 (21/5), matrix-2 exited 1 (24/2); subsequent fixes retained.
AFFECTED_REGRESSIONS: full-1.xml records no failures in the 8 requested affected
files; Windows symlink skip remains. Prior affected-1 exit 1: 278 passed/1 failed/1 skipped.
MCF01_REGRESSION: all 50 passed within Full Core, no separate command exit claimed.
RUNTIME_REGRESSIONS: within Full Core, skeleton 17, WP-14 31, WP-15 36, WP-16 58 passed;
binding suite passed. This is case evidence, not differential or Full Core PASS.
FULL_CORE: FULL_CORE_EXIT_CODE=1; 810 passed, 5 failed, 1 skipped (full-1.xml/log).
Full run preceded addition of 2 rollback tests; those subsequently passed in focused-final.
BASELINE_VALIDATOR: EXIT_CODE=0
GOVERNANCE_VALIDATOR: EXIT_CODE=0
GIT_DIFF_CHECK: EXIT_CODE=0
STABILITY_5_RUNS: NOT_EXECUTED after scope blocker; no deterministic stability PASS.
Historical pre-approval red runs and all implementation failed logs remain preserved.

SCHEMA_CHANGE: YES
RUNSTATE_CHANGE: NO
PUBLIC_API_CHANGE: NO
G30_CHANGED: NO
WP20_CHANGED: NO
SCORE_CHANGED: NO

KNOWN_LIMITATIONS:
- Full Core cannot pass as-is: tests hard-code head=0002 in
  services/core/tests/test_cp06_wp30_clean_install.py (lines 95,105),
  services/core/tests/test_g17_migration_restore_authority.py (lines 72,83),
  services/core/tests/test_wp23_backup_restore_migration.py (lines 131,144).
  These files are outside the authorized test allowlist and remain untouched.
  Required scope expansion: update head expectations to 0003 while preserving
  explicit historical 0001/0002 backup/downgrade and original-data assertions.
- Three WP23 backup failures in this full run are backup_not_isolated: chosen
  pytest basetemp is outside tempfile.gettempdir(). Subsequent verification needs
  an isolated writable temp root consistent with backup policy; do not change
  production backup protections. WP23's hard-coded head failure is currently masked.
- Windows policy skip: test_wp07_integration.py:799 real symlink creation denied;
  1 skipped, not counted as passed.
- Only isolated databases were migrated; no production migration/restore performed.
- Independent review and final fixed five-run acceptance remain outstanding.

NEXT_REQUIRED_ROLE: FRESH_INDEPENDENT_CODEX_REVIEWER (after authorized repair and
all required acceptance passes); immediate routing: HUMAN scope expansion decision.
No stage/commit/push/reset/clean/rebase or MCF-02. No VERIFIED_PASS claim.
