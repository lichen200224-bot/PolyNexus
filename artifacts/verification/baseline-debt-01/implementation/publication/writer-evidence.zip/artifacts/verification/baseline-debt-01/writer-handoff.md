# BASELINE-DEBT-01 WRITER HANDOFF

TASK_ID: BASELINE-DEBT-01
ATTEMPT: 1
START_SHA: 86d5939044c1d7ec2a991820f39287481ee9120f
BASELINE_DEBT_01_START_SHA: 86d5939044c1d7ec2a991820f39287481ee9120f
BRANCH: feature/baseline-debt-01-deterministic-lifecycle-cleanup
RESULT: ARCHITECTURE_GATE_REQUIRED
WRITER: Codex IMPLEMENTATION WRITER
REVIEWER: NOT_STARTED
ANTIGRAVITY_STATUS: NOT_REQUIRED (Core-only)
NEXT_REQUIRED_ROLE: HUMAN_ARCHITECTURE_GATE

TASK_DOC: docs/tasks/BASELINE-DEBT-01.md
HANDOFF_DOC: docs/12_HANDOFF_CURRENT.md
WORKTREE: C:/Users/shawn/OneDrive/文件/PONYNEXUS/baseline-debt-01
PYTHON: D:/AI學習教材/PolyNexus/.venv/Scripts/python.exe
ENVIRONMENT: Python 3.12.14, pytest 9.0.2, SQLAlchemy 2.0.50, Windows

ROOT_CAUSE_A: Four event read paths order by occurred_at and UUID4 id. No logical
append ordinal is persisted. All 12 equal-timestamp/reverse-ID write/read/reopen
combinations return the terminal event before STARTING. See task document for
CURRENT_SCHEMA, ROOT_CAUSE, WHY_EXISTING_SCHEMA_CANNOT_PROVE_TOTAL_ORDER,
MINIMAL_PROPOSED_SCHEMA_CHANGE, LEGACY_DATA_POLICY, BACKFILL_POLICY, UPGRADE_PLAN,
DOWNGRADE/RESTORE_PLAN, AFFECTED_FILES and TEST_PLAN.

ROOT_CAUSE_B: The 0.01s override affects outer workflow setup and every adapter
operation including cleanup. Both historical WP24 cases fail during start, before
their intended boundary. Separately, Event-synchronized outer cancellation reaches
the blocked collect/status coroutine but leaves RUNNING with no cleanup. A's
architecture stop is honored; B is investigated, not repaired.

ARCHITECTURE_GATE_REQUIRED: YES
SCHEMA_CHANGE: NO
MIGRATION_CHANGE: NO
PRODUCTION_SOURCE_CHANGE: NO
ADR_IMPACT: Proposed persisted ordering compatibility under ADR-004/007/008;
no frozen ADR text changed.
SCOPE_DEVIATION: NONE

CHANGED_FILES:
- docs/12_HANDOFF_CURRENT.md
- docs/tasks/BASELINE-DEBT-01.md
- services/core/tests/test_baseline_debt_01.py (untracked, intentionally red)
- artifacts/verification/baseline-debt-01/ (gitignored local evidence; inventory.json
  lists generated files, including logs, XML, JSON and fixture databases)

DETERMINISTIC_REPRO:
- Four write paths × three read paths, fixed equal timestamps, reverse lexical IDs,
  legal STARTING → RUNNING → COMPLETED, multiple events/transaction, new engine reload.
- Event barrier before cancelling collect; verifies cancellation reaches the blocked
  operation, then requires truthful terminal state. Actual state is RUNNING.
- Initial default pytest temp root denied access: 12 errors, exit 1. Preserved as
  environment evidence (ordering.log/xml), not conflated with product failures.

IMPLEMENTED_FIX:
- Local remote-tracking ref repaired using explicit fetch; persistent config unchanged.
- No product fix: A requires approved schema/legacy policy; B remains open.

## Executable command record

All commands run from WORKTREE with PYTHON above. `commands.json` expands every
pytest invocation to its exact executable/argument array and records actual exit
codes. Every pytest command uses `-B -m pytest`, `-o addopts= -q --tb=short`.
Every executable diagnostic after the first temp-root error uses a distinct
task-local `--basetemp`; no existing user temp tree was cleaned.

DEBT_MATRIX:
command: PYTHON -B -m pytest <exact 26 nodeids from debt-nodeids.json> -o addopts=
  -q --tb=short -ra --basetemp=artifacts/verification/baseline-debt-01/tmp-matrix
  --junitxml=artifacts/verification/baseline-debt-01/matrix.xml
exit_code: 1
passed: 11
failed: 15
skipped: 0
errors: 0
failure_semantics: test-results.json retains each testcase identity and assertion/error
  message; matrix.log retains full short tracebacks. Original nodeids were read from
  D:/AI學習教材/PolyNexus/artifacts/verification/mcf01-20260912/baseline-failures-command.json;
  exactly 26 selected, none substituted. Historical evidence is not current PASS.

AFFECTED_REGRESSIONS:
- command: PYTHON -B -m pytest services/core/tests/test_wp24_resource_guards.py
    services/core/tests/test_runtime_skeleton.py -o addopts= -q --tb=short -ra
    --basetemp=artifacts/verification/baseline-debt-01/tmp-timeout
    --junitxml=artifacts/verification/baseline-debt-01/timeout.xml
  exit_code: 1
  passed: 21
  failed: 2
  skipped: 0
- broader persistence/lifecycle/council/API/binding suites: NOT_RUN at Architecture Gate.

MCF01_REGRESSION:
exit_code: N/A — NOT_RUN at Architecture Gate
passed: N/A
failed: N/A
skipped: N/A

RUNTIME_WP14_WP15_WP16: NOT_RUN at Architecture Gate (runtime skeleton included above).

FULL_CORE:
exit_code: N/A — NOT_RUN at Architecture Gate
passed: N/A
failed: N/A
skipped: N/A

BASELINE_VALIDATOR:
command: PYTHON -B scripts/validate_baseline.py
exit_code: 0

GOVERNANCE_VALIDATOR:
command: powershell -NoProfile -ExecutionPolicy Bypass -File
  tools/validate-polynexus-governance.ps1 .
exit_code: 0

GIT_DIFF_CHECK:
command: git -c safe.directory=WORKTREE diff --check
exit_code: 0

REPEAT_STABILITY_PROOF:
runs: 5 fixed runs (not retry-until-green)
command: PYTHON -B -m pytest services/core/tests/test_baseline_debt_01.py -o addopts=
  -q --tb=short --basetemp=artifacts/verification/baseline-debt-01/tmp-repeat-N
  --junitxml=artifacts/verification/baseline-debt-01/repeat-N.xml
results: N=1,2,3,4,5 each exit 1; 0 passed / 13 failed / 0 errors / 0 skipped.
meaning: stable defect reproduction, NOT stable corrected behavior.

KNOWN_LIMITATIONS:
- Durable append order cannot be recovered reliably from existing declared fields.
- Proposed conservative legacy policy blocks nonempty ledgers without verified
  external ordering evidence; Human must decide before implementation.
- B cancellation repair and deterministic deadline seam are not implemented.
- Evidence artifacts are local/gitignored, not a pushed cross-machine checkpoint.

UNVERIFIED:
- Concurrent multi-process append, same-state adversarial execution, migration,
  backfill, backup/restore, fixed B cleanup/cancellation, broader required regression
  and Full Core, independent review. No release/production readiness claim.
- Windows symlink test not run; no skipped coverage is counted as passed.

G30_CHANGED: NO
WP20_CHANGED: NO
SCORE_CHANGED: NO
STAGED: EMPTY
COMMIT_PUSH_MERGE: NOT_EXECUTED

NEXT_ACTION: Human approves/revises the concrete ordering and legacy proposal in
the task document, including future exact source/migration/transaction allowlist.
Then resume the existing isolated branch, retain red tests, repair A/B, run all
required acceptance layers and hand off to a fresh independent reviewer. Do not
create another branch with this same name or rerun the original branch-create gate.

The mandatory stop comes from the user's original Architecture Stop Gate and
task contract. Repository skill `.agents/skills/polynexus-architecture-gate/SKILL.md`
also states: "Only implement after human/owner decision is recorded when the change
is architectural." No generic skill rule is used to expand the approval boundary.
